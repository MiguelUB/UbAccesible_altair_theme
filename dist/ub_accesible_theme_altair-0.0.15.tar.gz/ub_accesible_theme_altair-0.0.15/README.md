# Introduction

This library is a set of themes of the library vega-altair of python, with this
library we add a new theme for altair that be installable with a simple pip install