from .tokens import COLORS


def change_color_background(color: str):
    COLORS['background'] = color
